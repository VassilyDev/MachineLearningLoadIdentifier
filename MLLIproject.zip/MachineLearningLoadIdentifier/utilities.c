// MachineLearningLoadIdentifier program for Infineon PSoC 62S2 Wi-Fi BT Pioneer Kit and VY8CKIT-028-SENSE
// Build AI for the IoT contest @Hackster.io
// Alessandro Felicetti 2022

#include "cy_pdl.h"
#include "cyhal.h"
#include "cybsp.h"
#include "mtb_ssd1306.h"
#include "GUI.h"
#include "cy_rgb_led.h"
#include <utilities.h>

// UPDATE THE DISPLAY
void updateDisplay(){
	GUI_Clear();
	// Print ambient temperature
	char c[10];
	sprintf(c, "%2.0f", temperature);
	GUI_DispStringAt("Temp: ", 2, 20);
	GUI_DispStringAt(c, 45, 20);
	GUI_DispStringAt("C", 61, 20);
	// Print current and power
	if(f != 5){
		GUI_DispStringAt("I:", 2, 40);
		sprintf(c, "%3.0f", Irms);
		GUI_DispStringAt(c, 20, 40);
		GUI_DispStringAt("mA", 46, 40);
		GUI_DispStringAt("P:", 70, 40);
		sprintf(c, "%3.0f", Power);
		GUI_DispStringAt(c, 88, 40);
		GUI_DispStringAt("W", 114, 40);
	}

	// Print recognition result
	if(f == 5){
		// NOTHING
		GUI_DispStringAt("NO LOAD", 2, 2);
	}
	if(f == 3){
		// VACUUM
		GUI_DispStringAt("VACUUM", 2, 2);
	}
	if(f == 1){
		// PC
		GUI_DispStringAt("PC", 2, 2);
	}
	if(f == 2){
		// LOW POWER LOAD
		GUI_DispStringAt("LOW POWER", 2, 2);
	}
	if(f == 4){
		// HEATER
		GUI_DispStringAt("HEATER", 2, 2);
	}
}
