// MachineLearningLoadIdentifier program for Infineon PSoC 62S2 Wi-Fi BT Pioneer Kit and VY8CKIT-028-SENSE
// Build AI for the IoT contest @Hackster.io
// Alessandro Felicetti 2022

#include "cy_pdl.h"
#include "cyhal.h"
#include "cybsp.h"
#include <sensor.h>
#include <utilities.h>

// VARIABLES
int counter_0 = 0;
int counter_1 = 0;
int counter_2 = 0;

int main(void)
{
	// INITIALIZE BOARD AND SENSORS
	cybsp_init();
	__enable_irq();
	initIO();
	// MAIN LOOP
	for (;;){
#if (APPLICATION_RUNNING_MODE == DATA_CAPTURE_RUNNING_MODE)
		captureADC();
		serialInt();
		cyhal_system_delay_us(500);
#endif
#if (APPLICATION_RUNNING_MODE == RECOGNITION_RUNNING_MODE)
		recognitionADC();
		cyhal_system_delay_us(333);
		counter_0++;
		counter_1++;
		// UPDATE THE DISPLAY EVERY 1000ms circa
		if(counter_0 > 3000){
			updateDisplay();
			counter_0 = 0;
		}
		// UPDATE THE IO EVERY 3000ms circa
		if(counter_1 > 9000){
			updateIO();
			counter_1 = 0;
		}
#endif
	}
}
